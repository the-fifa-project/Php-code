BEFORE LAUNCHING:
Copy Savedata.json & Matchdata.json to your desktop.
If you did not do this, delete the created files on your desktop and 
copy the .json files to your desktop.

Note:
You can move the .json files around in your pc when you are not using 
the program, make sure you have 
the .json files on your desktop when using the program.
